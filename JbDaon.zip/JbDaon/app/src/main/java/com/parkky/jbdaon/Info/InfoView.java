package com.parkky.jbdaon.Info;

public class InfoView {
}
