package com.parkky.jbdaon.DataJson;

import com.google.gson.annotations.SerializedName;

public class InfoListJson2 {
    @SerializedName("id")
    public String id;
    @SerializedName("title")
    public String title;
    @SerializedName("wname")
    public String wname;
    @SerializedName("wdate")
    public String wdate;
}
